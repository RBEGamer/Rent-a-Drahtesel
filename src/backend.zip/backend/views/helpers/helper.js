var helper = {
	sayHi: function(name) {
		return "Hello " + name;
	}
}
module.exports = helper;