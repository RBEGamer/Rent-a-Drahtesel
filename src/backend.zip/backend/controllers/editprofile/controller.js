module.exports = function(app, passport, verificationMail) {

}