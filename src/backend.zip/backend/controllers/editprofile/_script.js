$(document).ready(function () {
    $('#upload').click(function() {
        console.log("kommt an!");
        $('#postform').submit();
    });
});