
        function fahrräder() {
           
            document.getElementById("meineFahrräder").style.display = "block";
            document.getElementById("meineBestellungen").style.display = "none";
        }

        function bestellungen() {
           
            document.getElementById("meineFahrräder").style.display = "none";
            document.getElementById("meineBestellungen").style.display = "block";
        }
